<?php
$entry_point_registry['searchBarGetResults'] = array(
    'file' => 'custom/searchBarGetResults.php',
    'auth' => true,
);



